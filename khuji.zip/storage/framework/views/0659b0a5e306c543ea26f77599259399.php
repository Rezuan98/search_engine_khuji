

<?php $__env->startSection('admin'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 mt-4">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title">Upload a CSV file</h3>
                    <form action="<?php echo e(route('store.data')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="file" name="csv" id="csv" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-success m-4">Add Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/admin/add_new_data.blade.php ENDPATH**/ ?>