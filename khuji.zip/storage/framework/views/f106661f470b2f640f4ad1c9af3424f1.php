


<?php $__env->startSection('admin'); ?>

<div class="page-content">

  <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
    <div>
      <h4 class="mt-5 mb-md-0 my-5">Welcome to Khuji</h4>
    </div>
  
  </div>






</div>


<?php $__env->stopSection(); ?>





















<?php echo $__env->make('admin.admin_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/admin/index.blade.php ENDPATH**/ ?>