

<?php $__env->startSection('maincontent'); ?>

<div class="container">
    <div class="row mt-5">
        <div class="col-md-8">
            <h2>Search results</h2>

            <!-- Search Results -->
            <?php if($results->isEmpty()): ?>
                <h4>No results found.</h4>
            <?php else: ?>
                <div class="row">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($result->title); ?></h5>
                                    <p class="card-text"><strong>Name:</strong> <?php echo e($result->name); ?></p>
                                    <p class="card-text"><strong>Email:</strong> <a href=" mailto:<?php echo e($result->email); ?>"><i class="fa-solid fa-envelope"></i> <?php echo e($result->email); ?></a></p>
                                    <p class="card-text"><strong>Website:</strong> <a href="<?php echo e($result->website); ?>"><?php echo e($result->website); ?></a></p>
                                    <p class="card-text"><strong>Address:</strong> <?php echo e($result->address); ?></p>
                                    <p class="card-text"><strong>Description:</strong> <?php echo e($result->description); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination Links -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($results->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/search_results.blade.php ENDPATH**/ ?>