<footer class="footer text-white" style="background-color: rgb(14, 90, 65);">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <h3>Visit Our Center</h3>
                <h4>About Our Company</h4>
                <ul>
                    <li>OUr offerings</li>
                    <li>newsrooms</li>
                    <li>investors</li>
                    <li>blog</li>
                    <li>careers</li>
                    <li>gift cards</li>

                </ul>
            
            </div>
            <div class="col-lg-4">

                <h3>Rules and Regulations</h3>
                <h4>For your safety</h4>
                <ul>
                    <li>OUr offerings</li>
                    <li>newsrooms</li>
                    <li>investors</li>
                    <li>blog</li>
                    <li>careers</li>
                    <li>gift cards</li>

    
            </div>
            <div class="col-lg-4">
                <h3>Find Us On</h3>
                <h4>Many kind of social platform</h4>
                <ul>
                    <li>OUr offerings</li>
                    <li>newsrooms</li>
                    <li>investors</li>
                    <li>blog</li>
                    <li>careers</li>
                    <li>gift cards</li>

    
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4" style="height: 70px;width:100%; background-color:rgb(11, 5, 43);border-radius:15px; padding:15px;">
                <p><i class="fa-solid fa-copyright"></i>  Copyright Reserved:Designed and Developed By Rezuan Ahmmed</p>
            </div>
            <div class="col-sm-4">
                
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/landing/footer.blade.php ENDPATH**/ ?>