

<?php $__env->startSection('keyTitle', 'Homepage'); ?>



<?php $__env->startSection('maincontent'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
   

<div class="container">
    <div class="row mt-5">
        <h1>Search On Khuji</h1>
      <form action="<?php echo e(route('search.data')); ?>" method="get">
        <input type="text" name class="form-control"  name="" id="">
        <button class="btn btn-success m-3" type="submit">Search</button>
      </form>
       
    </div>

</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/index.blade.php ENDPATH**/ ?>