<nav class="navbar">
    <a href="#" class="sidebar-toggler">
      <i data-feather="menu">KHUJI</i>
    </a>
    <div class="navbar-content">
      <form class="search-form">
        <div class="input-group">
          <div class="input-group-text">
            <i data-feather="search"></i>
          </div>
          <input type="text" class="form-control" id="navbarForm" placeholder="Search here...">
        </div>
      </form>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          
         
        </li>
       
        
       
          
           <?php
        $id = Auth::user()->id;
             $data = App\Models\User::find($id);
  
            
        ?> 
           
           
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          
          </a>
  
         
          
        </li>
      </ul>
    </div>
  </nav>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  <?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/admin/include/header.blade.php ENDPATH**/ ?>