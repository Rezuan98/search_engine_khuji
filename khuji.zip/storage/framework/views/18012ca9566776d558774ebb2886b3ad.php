<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php echo $__env->yieldContent('keyTitle'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/preloader.css')); ?>">
   
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-EXAMPLE_HASH" crossorigin="anonymous" />
   
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome-free-6.5.2-web/css/all.min.css')); ?>">
    <link rel="icon" type="image/png" style="height: 12px;width:16px;" href="<?php echo e(asset('images/logo/ride3.png')); ?>"> 
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >
</head>
<body>
   

     
            <?php echo $__env->make('landing.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        
           <?php echo $__env->yieldContent('maincontent'); ?>
        
            <?php echo $__env->make('landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


       

       


    
    
    
    

        <script>
            
function showLoading() {
  document.querySelector('#loading').classList.add('loading');
  document.querySelector('#loading-content').classList.add('loading-content');
}

function hideLoading() {
  document.querySelector('#loading').classList.remove('loading');
  document.querySelector('#loading-content').classList.remove('loading-content');
}


        </script>
        
<script src="<?php echo e(asset('bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="https://kit.fontawesome.com/dc30f419d9.js" crossorigin="anonymous"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"
    switch(type){
       case 'info':
       toastr.info(" <?php echo e(Session::get('message')); ?> ");
       break;
   
       case 'success':
       toastr.success(" <?php echo e(Session::get('message')); ?> ");
       break;
   
       case 'warning':
       toastr.warning(" <?php echo e(Session::get('message')); ?> ");
       break;
   
       case 'error':
       toastr.error(" <?php echo e(Session::get('message')); ?> ");
       break; 
    }
    <?php endif; ?> 
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/landing/landing.blade.php ENDPATH**/ ?>