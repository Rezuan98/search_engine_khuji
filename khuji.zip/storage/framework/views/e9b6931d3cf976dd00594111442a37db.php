

<?php $__env->startSection('admin'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 mt-4">
            <table class="table table-bordered table-responsive mt-5" style="margin-top:100px;">

               <h1 class="mt-5"> All Data Inserted BY Admins</h1>
                <thead class="thead-light">
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Website</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($adata->id); ?></td>
                        <td><?php echo e($adata->email); ?></td>
                        <td><?php echo e($adata->name); ?></td>
                        <td><?php echo e($adata->website); ?></td>
                        <td><?php echo e(Str::limit($adata->description, 20)); ?></td>
                        <td>
                            <button class="btn btn-success btn-sm">Edit</button>
                            <button class="btn btn-warning btn-sm">Delete</button>
                            <button class="btn btn-info btn-sm">View</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskProject\khuji\resources\views/admin/show_data.blade.php ENDPATH**/ ?>